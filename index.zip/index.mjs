import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
const { REGION, EMAIL } = process.env
const ses = new SESClient({ region: REGION });

export const handler = async(event) => {
  const { name, age } = JSON.parse(event.body);
  console.log(name, age);
  try {
    const command = new SendEmailCommand({
    Destination: {
      ToAddresses: [EMAIL],
    },
    Message: {
      Body: {
        Text: { Data: "Hello " + name + "!" },
      },
      Subject: { Data: "You are "  + age },
    },
    Source: EMAIL,
  });
    let response = await ses.send(command);
  return {
    statusCode: 200,
    body: JSON.stringify(response),
  };
  }
  catch (error) {
    console.log('Error: ' + error);
    return error;
  }
};

